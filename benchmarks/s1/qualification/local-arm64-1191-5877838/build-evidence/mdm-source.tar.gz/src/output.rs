use crate::error::MdmError;
use crate::source_record::quote_identifier;

const SYSTEM_COLUMNS: [&str; 10] = [
    "mdm_id",
    "member_count",
    "has_review",
    "last_change_revision",
    "tableoid",
    "xmin",
    "cmin",
    "xmax",
    "cmax",
    "ctid",
];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct OutputField {
    pub name: String,
    pub ordinal: u16,
    pub type_name: String,
}

pub fn output_table_ddl(
    entity_name: &str,
    fields: &[OutputField],
) -> Result<Vec<String>, MdmError> {
    if entity_name.is_empty()
        || entity_name.len() > 63
        || entity_name.len() + "_members".len() > 63
        || entity_name.len() + "_review".len() > 63
        || entity_name.contains('\0')
    {
        return Err(MdmError::OutputInvalid(
            "entity output name is invalid".into(),
        ));
    }
    validate_output_fields(fields)?;
    if fields.iter().any(|field| {
        field
            .type_name
            .chars()
            .any(|character| !(character.is_ascii_alphanumeric() || "_ .\"[]".contains(character)))
            || field.type_name.contains("--")
    }) {
        return Err(MdmError::OutputInvalid(
            "field type name is not a portable PostgreSQL type name".into(),
        ));
    }
    let golden = fields
        .iter()
        .map(|field| format!("    {} {}", quote_identifier(&field.name), field.type_name))
        .collect::<Vec<_>>();
    let golden = if golden.is_empty() {
        String::new()
    } else {
        format!("{},\n", golden.join(",\n"))
    };
    let entity = quote_identifier(entity_name);
    let members = quote_identifier(&format!("{entity_name}_members"));
    let review = quote_identifier(&format!("{entity_name}_review"));
    Ok(vec![
        format!(
            "CREATE TABLE mdm_out.{entity} (\n    mdm_id uuid PRIMARY KEY,\n{golden}    member_count bigint NOT NULL,\n    has_review boolean NOT NULL,\n    last_change_revision bigint NOT NULL\n);"
        ),
        format!(
            "CREATE TABLE mdm_out.{members} (\n    source_record_id uuid PRIMARY KEY,\n    source_name name NOT NULL,\n    source_id jsonb NOT NULL,\n    mdm_id uuid NOT NULL,\n    active boolean NOT NULL,\n    first_membership_revision bigint NOT NULL,\n    last_membership_revision bigint NOT NULL,\n    membership_reason text NOT NULL,\n    last_change_revision bigint NOT NULL\n);"
        ),
        format!(
            "CREATE TABLE mdm_out.{review} (\n    review_id uuid PRIMARY KEY,\n    issue_key bytea NOT NULL,\n    occurrence integer NOT NULL,\n    status text NOT NULL,\n    severity text NOT NULL,\n    reason_code text NOT NULL,\n    subjects jsonb NOT NULL,\n    masked_summary jsonb NOT NULL,\n    opened_revision bigint NOT NULL,\n    resolved_revision bigint,\n    last_change_revision bigint NOT NULL,\n    concurrency_version bigint NOT NULL\n);"
        ),
    ])
}

pub fn validate_output_fields(fields: &[OutputField]) -> Result<(), MdmError> {
    let mut names = std::collections::BTreeSet::new();
    for (index, field) in fields.iter().enumerate() {
        if field.name.is_empty() || field.name.len() > 63 {
            return Err(MdmError::OutputInvalid(format!(
                "field name {} must be 1 through 63 UTF-8 bytes",
                field.name
            )));
        }
        if SYSTEM_COLUMNS
            .iter()
            .any(|reserved| reserved.eq_ignore_ascii_case(&field.name))
            || !names.insert(field.name.to_ascii_lowercase())
        {
            return Err(MdmError::OutputInvalid(format!(
                "field name {} collides with an output column",
                field.name
            )));
        }
        if field.ordinal as usize != index + 1 {
            return Err(MdmError::OutputInvalid(format!(
                "field {} has non-contiguous ordinal {}",
                field.name, field.ordinal
            )));
        }
        if field.type_name.trim().is_empty() {
            return Err(MdmError::OutputInvalid(format!(
                "field {} has no PostgreSQL type",
                field.name
            )));
        }
    }
    Ok(())
}

pub fn validate_append_only(
    previous: &[OutputField],
    desired: &[OutputField],
) -> Result<(), MdmError> {
    validate_output_fields(previous)?;
    validate_output_fields(desired)?;
    if desired.len() < previous.len() || previous.iter().zip(desired).any(|(old, new)| old != new) {
        return Err(MdmError::OutputInvalid(
            "published golden fields are append-only and cannot be removed, renamed, reordered, or retyped"
                .into(),
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn field(name: &str, ordinal: u16, type_name: &str) -> OutputField {
        OutputField {
            name: name.into(),
            ordinal,
            type_name: type_name.into(),
        }
    }

    #[test]
    fn output_fields_are_append_only() {
        let old = vec![field("name", 1, "text")];
        assert!(
            validate_append_only(&old, &[field("name", 1, "text"), field("email", 2, "text")])
                .is_ok()
        );
        assert!(validate_append_only(&old, &[field("email", 1, "text")]).is_err());
    }

    #[test]
    fn output_ddl_quotes_names_and_preserves_field_order() {
        let ddl = output_table_ddl("customer", &[field("full name", 1, "text")]).unwrap();
        assert!(ddl[0].contains("\"full name\" text"));
        assert!(ddl[1].contains("customer_members"));
        assert!(ddl[2].contains("customer_review"));
    }

    #[test]
    fn output_schema_rejects_reserved_columns_and_names_that_would_truncate() {
        assert!(validate_output_fields(&[field("MDM_ID", 1, "text")]).is_err());
        assert!(
            validate_output_fields(&[field("email", 1, "text"), field("EMAIL", 2, "text")])
                .is_err()
        );
        assert!(output_table_ddl(&"a".repeat(56), &[]).is_err());
        assert!(output_table_ddl(&"a".repeat(55), &[]).is_ok());
    }
}
