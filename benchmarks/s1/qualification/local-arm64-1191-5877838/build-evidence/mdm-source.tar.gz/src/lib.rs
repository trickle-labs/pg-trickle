#![deny(unsafe_op_in_unsafe_fn)]
#![cfg_attr(not(test), deny(clippy::unwrap_used))]

pub mod affected;
pub mod api;
pub mod candidate;
pub mod catalog;
pub mod cleaners;
pub mod comparators;
pub mod constraint;
pub mod decision;
pub mod definition;
pub mod error;
pub mod evaluation;
pub mod evidence;
pub mod golden;
pub mod graph_spec;
pub mod identity;
pub mod integration;
pub mod normalization;
pub mod output;
pub mod pair;
pub mod policy;
pub mod presets;
pub mod resolver;
pub mod review;
pub mod schema;
pub mod semantics;
pub mod source_record;
pub mod version;

::pgrx::pg_module_magic!();

fn raise(error: error::MdmError) -> ! {
    pgrx::error!("{}: {}", error.code(), error)
}

#[cfg(feature = "pg_test")]
#[allow(dead_code)]
pub mod pg_test {
    pub fn setup(_options: Vec<&str>) {}

    pub fn postgresql_conf_options() -> Vec<&'static str> {
        vec!["shared_preload_libraries = 'pg_trickle'"]
    }
}
