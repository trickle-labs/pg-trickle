# pg_mdm

**Deterministic entity resolution and golden records, designed to run inside PostgreSQL.**

> [!IMPORTANT]
> The v0.14.1 release is qualified with `pg_trickle` 0.108.3. This adapter accepts the exact Graph V1.2 v2 and v3 feature vectors. It consumes Delta V1.1 terminal changes and adds bound stewardship policy intents with durable receipts.

Most organizations have several records for the same customer, company, supplier, or product. Those records rarely agree perfectly: names are formatted differently, contact details go stale, source systems reuse identifiers, and one weak match can accidentally join two unrelated groups. `pg_mdm` resolves those records into durable real-world entities while keeping every automatic decision deterministic, conservative, and explainable.

The project is built around a deliberate division of responsibility. [`pg_trickle`](https://github.com/trickle-labs/pg-trickle) captures source changes and incrementally maintains relational facts such as normalized values, candidate pairs, and matching evidence. `pg_mdm` decides what those facts mean: which records belong together, which human decisions take precedence, which stable ID survives a merge or split, which value becomes golden, and which uncertain cases need review. In short, **`pg_trickle` maintains changing relational facts; `pg_mdm` decides identity.**

## Install v0.14

The updated v0.14 adapter source supports PostgreSQL 18 with the checksum-pinned `pg_trickle` 0.108.3 package. The released pg_mdm 0.14.0 package was qualified with pg_trickle 0.108.0 and does not accept the v3 profile. Add `pg_trickle` to `shared_preload_libraries`, restart PostgreSQL, and install `pg_trickle` first. [`DEPENDENCIES.md`](DEPENDENCIES.md) records the package URL and checksum. Before upgrading pg_trickle to 0.108.3, request a resnapshot for each active output-delta consumer; the next pg_mdm refresh rebuilds its consumer state from the fresh snapshot.

The extension stores definitions, installs private Graph V1.2 members, consumes Delta V1.1 changes, and publishes PostgreSQL output tables in one transaction. The v0.14 CI suite compares differential and full results, tests affected resolution, and covers rollback, retry, policy intents, upgrade, and restore on PostgreSQL 18.

Build and copy the package:

```bash
cargo pgrx package --pg-config "$(command -v pg_config)"
sudo cp target/release/pg_mdm-pg18/*/lib/postgresql/18/lib/pg_mdm.* "$(pg_config --pkglibdir)/"
sudo cp target/release/pg_mdm-pg18/*/share/postgresql/18/extension/pg_mdm* "$(pg_config --sharedir)/extension/"
```

Install both extensions as a database administrator:

```sql
CREATE EXTENSION pg_trickle;
CREATE EXTENSION pg_mdm;

CREATE ROLE mdm_helper_owner NOLOGIN NOSUPERUSER NOBYPASSRLS;
```

Assign the protected objects to the helper owner before you grant action access:

```bash
psql --set=helper_owner=mdm_helper_owner --file=sql/configure_helper.sql my_database
```

Create application roles outside the extension. Give the administrator role only the actions it needs:

```sql
CREATE ROLE app_mdm_admin NOLOGIN NOSUPERUSER NOBYPASSRLS;
CREATE ROLE app_login LOGIN NOSUPERUSER NOBYPASSRLS;
GRANT app_mdm_admin TO app_login WITH SET TRUE, INHERIT FALSE;

GRANT USAGE ON SCHEMA mdm_admin TO app_mdm_admin;
GRANT EXECUTE ON FUNCTION mdm_admin.verify_installation() TO app_mdm_admin;

GRANT USAGE ON SCHEMA mdm TO app_mdm_admin;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA mdm TO app_mdm_admin;
```

Connect as `app_login`, select the action role, and run the check:

```sql
SET ROLE app_mdm_admin;
SELECT mdm_admin.verify_installation();
```

The function rejects superusers, `BYPASSRLS` roles, login-capable helper owners, helper owners with role memberships, and mismatched function and table owners. It records `session_user` as `actor_name` and the selected role as `actor_role_name`. Callers cannot supply either value, the outcome, the status, or the result code.

Run `sql/configure_helper.sql` again after an extension upgrade or a clean logical restore, then reapply action grants. After a logical restore, [rebind the restored entities](#rebind-restored-entities) before using definition actions. PostgreSQL includes `mdm_internal.operations` data in logical dumps. The helper writes only committed success records; a transaction rollback removes its operation row.

`mdm_admin.verify_installation()` returns `MDM_OK` when the helper owner, application role, and required `pg_trickle` capabilities pass validation. Other stable result codes are:

| Code | Meaning |
|---|---|
| `MDM_OK` | The installation check succeeded. |
| `MDM_PGT_CAPABILITY_MISSING` | Graph V1 is absent. |
| `MDM_PGT_CAPABILITY_VERSION` | Graph V1 has an unsupported major version. |
| `MDM_PGT_CAPABILITY_INVALID` | The capability response has duplicate or invalid rows. |
| `MDM_PGT_CAPABILITY_DISABLED` | Graph V1 1.x exists but is disabled. |
| `MDM_HELPER_OWNER_UNSAFE` | Protected objects do not have the documented helper owner. |
| `MDM_UNAUTHORIZED` | The authenticated or selected role is unsafe. |
| `MDM_OPERATION_STATE` | A running operation could not commit as succeeded. |
| `MDM_INTERNAL` | PostgreSQL SPI returned an unexpected error. |

For a guided example with sample data and expected results, follow the
[30-minute customer tutorial](TUTORIAL.md).

## Define and refresh an entity

The selected execution role needs schema `USAGE` and table `SELECT, MAINTAIN` on each source. The source owner grants these privileges. `pg-mdm` does not grant access to source tables.

Grant Graph V1 access to the execution role, then create the definition as that role:

```sql
GRANT USAGE ON SCHEMA pgtrickle TO app_mdm_admin;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA pgtrickle TO app_mdm_admin;
GRANT USAGE ON SCHEMA public TO app_mdm_admin;
GRANT SELECT, MAINTAIN ON public.crm_customer TO app_mdm_admin;

SET ROLE app_mdm_admin;
SELECT * FROM mdm.create(mdm.entity(
    name => 'customer',
    sources => ARRAY[mdm.source(
        name => 'crm',
        relation => 'public.crm_customer'::regclass,
        source_id => ARRAY['id'],
        mode => 'tracked',
        fields => '{"name":"display_name","email":"email_address"}'::jsonb,
        row_changed_at => 'updated_at')],
    fields => ARRAY[
        mdm.field(name => 'name', type => 'text', cleaner => 'company_name'),
        mdm.field(name => 'email', type => 'text', cleaner => 'email')],
    matches => ARRAY[mdm.match(
        name => 'same_email',
        fields => ARRAY['email'],
        comparison => 'exact',
        strength => 'identity',
        evidence_group => 'email')],
    golden_values => ARRAY[mdm.golden_value(
        field => 'name', policy => 'prefer_source', sources => ARRAY['crm'])]));
SELECT mdm.refresh('customer', 'ALLOW');
RESET ROLE;
```

Grant consumers access to the three output tables after the first refresh creates them: `mdm_out.customer`, `mdm_out.customer_members`, and `mdm_out.customer_review`. Use `mdm.describe('customer', 'summary')` to inspect the definition and graph state. Use `mdm.preview()` to validate a proposed change before activating it.

`full_policy = 'ALLOW'` lets Graph V1 use FULL when a compiled graph stage has no proven differential plan. Exact Delta V1 ranges use affected resolution. Gaps, invalidations, contract changes, graph transitions, and uncertain limits use the full resolver. `mdm_admin.rebuild()` always uses the full resolver without replacing the identity ledger.

## Roll out compiler v10

Keep `full_policy = 'ALLOW'` during the rollout. Use `ERROR` only in qualification tests.

1. Request a resnapshot for each active output-delta consumer, upgrade `pg_trickle` to 0.108.3, then install the adapter containing this compatibility fix.
2. Pick one entity as the canary. Capture its public output rows and `mdm.describe('<entity>', 'summary')` result.
3. Grant the entity administrator access to `mdm_admin.recompile(text)` and run `mdm_admin.recompile('<entity>')`.
4. Run `mdm.refresh('<entity>', 'ALLOW')`. The first refresh after the graph transition uses the full resolver. Confirm that the public rows are unchanged and `delta_lag` is zero.
5. Apply one representative source change. Confirm that `resolver_strategy` is `affected` and `unexpected_full_fallbacks` is empty.
6. Repeat steps 2 through 5 for the remaining entities.

Alert when a steady-state refresh reports a full resolver fallback or an unexpected FULL graph node. Recovery refreshes, rebuilds, graph transitions, invalidations, and resnapshots are expected full cases.

The Docker E2E run also executes `tests/incremental_qualification.sql`. It
measures 30 affected-refresh samples after five warmups at 128 and 2,048
records, and compares the complete public publication with an administrative
full rebuild after every sample. The retained report is observational; it has
no machine-dependent timing threshold.

Strict graph-wide `full_policy = 'ERROR'` qualification still depends on the
pg-trickle changes in
[`PG_TRICKLE_INCREMENTAL_REQUIREMENTS.md`](PG_TRICKLE_INCREMENTAL_REQUIREMENTS.md).
Do not treat the affected-resolver qualification as proof that every graph
node is differential.

## Rebind restored entities

Logical dumps preserve entity definitions, source identities, and graph artifacts. Database-local role and relation OIDs are derived bindings and are excluded from dumps.

After restoring the source tables and durable MDM data, run `sql/configure_helper.sql` and reapply action grants. Restore the execution role's source privileges and row-level security policies before rebinding.

Connect as a superuser, grant the stored execution role access to `rebind`, and select that role:

```sql
GRANT USAGE ON SCHEMA mdm_admin TO app_mdm_admin;
GRANT EXECUTE ON FUNCTION mdm_admin.rebind(text) TO app_mdm_admin;
SET ROLE app_mdm_admin;
SELECT mdm_admin.rebind('customer');
RESET ROLE;
```

Repeat the call for each restored entity under its stored execution role. `rebind` requires a superuser-authenticated session, so an application login cannot use it even with the function grant. Source validation runs under the selected role's privileges and row-level security.

Rebinding checks the desired definition's mappings and every retained source identity, including sources removed from the current definition. The portable relation names and frozen key contracts must match. The call replaces derived role and source bindings and records the operation without changing definitions, artifacts, or digests. It also supports an explicitly approved replacement of a role or source table under the same name and contract.

## How it works

A user defines an entity such as `customer`, maps columns from PostgreSQL source relations to logical fields, declares which agreements count as identity evidence, and chooses how each golden value should be selected. On refresh, `pg_trickle` updates a private evidence graph and `pg_mdm` runs a conservative resolver over the complete evidence set. The resolver publishes the new membership map, golden records, and review queue in the same transaction as the consumed source frontier, so readers see either the previous complete result or the next complete result, never a half-published state.

```text
PostgreSQL source relations
            |
            v
Private pg_trickle graph
  normalized values, candidate pairs, evidence
            |
            v
pg_mdm resolver
  decisions, clustering, stable IDs, golden values
            |
            v
Public PostgreSQL tables
  mdm_out.<entity>
  mdm_out.<entity>_members
  mdm_out.<entity>_review
```

The V1 public model uses `source`, `field`, `match`, `entity`, and `golden_value`. Its primary actions are `create`, `describe`, `preview`, `refresh`, and `explain`. Every mastered entity produces three ordinary PostgreSQL tables: one row per resolved entity, a durable mapping from source records to entities, and a review queue for ambiguity or conflict. Consumers can query those tables with SQL and observe their transactionally complete changes through standard PostgreSQL triggers or logical decoding.

## What makes the design different

`pg_mdm` treats candidate discovery as part of correctness, not merely a performance detail. A configured matching rule must examine every pair inside its declared candidate predicates. If an oversized block, missing dependency, unsupported extension version, or resource limit prevents complete evaluation, refresh fails and the previous publication remains readable. The system never turns skipped work into evidence that two records do not match.

Clustering is conservative for the same reason. One matching email or phone number may join two individual records, but a chain of shared values cannot keep growing an established entity without stronger independent support. Explicit steward decisions remain durable, cannot-link decisions are enforced across whole components, and automatic authoritative conflicts go to review. Stable `mdm_id` values follow documented merge and split rules, while every golden value retains the source, policy, tie break, definition version, and publication revision that selected it.

The design also separates semantic choices from physical execution. Cleaners, candidate predicates, pair decisions, clustering rules, stable-ID reconciliation, and golden-value policies are pinned by version. Indexes, query plans, and maintenance strategies may change without redefining identity, provided they produce the same logical evidence and result. This makes rebuilds, upgrades, explanations, and regression tests part of the product contract rather than afterthoughts.

## Project status

The v0.14.1 release admits the checksummed `pg_trickle` 0.108.3 artifact; its graph SQL still uses the preserved v2 encoder. Before upgrading to 0.108.3, request resnapshots for active output-delta consumers; pg_mdm rebuilds their state on the next refresh. v0.14 adds policy-intent bindings, atomic control updates, immutable receipts, and fail-closed retry behavior on top of v0.13's differential graph refresh.

The post-V1 capability catalogue is cumulative rather than a replacement for V1. It lists candidate work selected only when a deployment demonstrates the need, while preserving the same five nouns, five actions, and three primary outputs. Each optional feature must declare its dependencies, deterministic semantics, migration path, failure boundary, and retention needs; unsupported combinations fail closed instead of silently producing a weaker answer.

Read the design documents for the normative details:

- [DESIGN_V1.md](DESIGN_V1.md) defines the proposed first open-source release, including its SQL model, algorithms, invariants, security boundary, and acceptance criteria.
- [DESIGN_V2.md](DESIGN_V2.md) is the post-V1 capability catalogue and dependency order. It is not an approved delivery backlog.
- [ROADMAP.md](ROADMAP.md) divides the V1 implementation into small development releases and defines the V1.0 release gate.

## Contributing

The most useful contributions at this stage are concrete design reviews. A good review identifies a source-system behavior, matching failure, stewardship workflow, PostgreSQL constraint, or operational recovery case that the current contracts do not handle. Proposed changes should preserve complete candidate evaluation, deterministic results, atomic publication, durable identity, and bounded explanation, or state plainly why one of those guarantees needs to change.

Implementation work should follow the V1 release boundary rather than pulling roadmap features into the first compatibility promise. In particular, the public SQL API requires `external_graph_refresh` major 1 through `pgtrickle.integration_capabilities()` and a shared conformance suite for graph contracts, transactional refresh, rollback, concurrency, source boundaries, durable `EXTERNAL` orchestration, clone isolation, and recovery.

## License

`pg_mdm` is licensed under the [Apache License 2.0](LICENSE).
