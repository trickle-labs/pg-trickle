# Agent Configuration

You are an expert developer. When modifying code, NEVER output the entire file. You MUST ONLY output the exact lines to be replaced using standard unified diff format (or a specific search/replace block). Be extremely concise. Do not overengineer.

## Be cost efficient

Try to be extremely conservative with the input tokens. Use adaptive polling intervals instead of polling every 30 seconds for a test that will take 45 minutes.

## Rules

- Never use HEREDOC.
- After every git commit make sure that the commit messages isn't garbled.
- After creating or updating a pull request title or body make sure that they aren't garbled.

## Test Output: Summary Lines Only

After any test run, extract only the summary — do not paste full passing test output into the conversation:

```
rtk cargo test ... 2>&1 | grep -E "^test .* (ok|FAILED|ignored)|^test result:|^FAILED$|^error"
```

Show full output **only for FAILED tests**. Passing test noise balloons the cache and gets re-read on every subsequent turn, multiplying token costs 10–30×.

## Writing tests

All tests must test and verify the exact, and ideally, full output instead of counts and other simplifications. This is important so that the tests can cover more ground.

## RTK Wrapper

Always use rtk wrapper for all commands. Examples:

- `rtk grep "pattern"` instead of `grep -r "pattern"`
- `rtk read <file>` instead of `cat <file>`
- `rtk ls` instead of `ls`
- `rtk find "*.md" .` instead of `find . -name "*.md"`
- `rtk cargo test` instead of `cargo test`
- `rtk cargo build` instead of `cargo build`
- `rtk cargo clippy` instead of `cargo clippy`
- `rtk git log` instead of `git log`
- `rtk git status` instead of `git status`
- `rtk git diff` instead of `git diff`
- `rtk gh pr view <num>` instead of `gh pr view <num>`
- `rtk gh pr checks <num>` instead of `gh pr checks <num>`

## Code Exploration Protocol

When exploring a codebase or understanding a module:

1. **Structure first** — run the appropriate command for the language:

   Rust: `rg "^\s*(pub\s+)?(async\s+)?fn |^\s*(pub\s+)?(struct|enum|trait|impl)\s" src/ --no-heading -n`

   Use `^\s*` not `^` — Rust methods inside impl blocks are indented. The `^` pattern misses ~70% of them.

2. Identify 2-3 relevant functions from the signatures
3. Read only those functions with line offset (not the whole file)
4. Cross-reference callers with Grep if needed

Never read a file end-to-end when exploring. Structure first, drill second.

### PR Body Generation Rules
- **No Variations:** Follow the requested Markdown schema exactly.
- **Table Constraints:** If generating test matrices, use a strict format. Do not nest complex types inside table columns.
- **No Repetition:** If you find yourself repeating a phrase or token pattern, immediately truncate the section and move to the next header.
- **Code Block Integrity:** Never break out of inline code blocks (` `) or structural lines without closing them.
- **Confirm:** Make sure that PR body is not garbled. If so fix it. Then confirm one more time.

## Agent skills

### Issue tracker

Issues and specs live in GitHub Issues; use `gh`. See `docs/agents/issue-tracker.md`.

### Triage labels

Use the five canonical triage labels. See `docs/agents/triage-labels.md`.

### Domain docs

Single-context domain docs use root `CONTEXT.md` and `docs/adr/`. See `docs/agents/domain.md`.
